"""Optional, bounded diagnostics to a team-owned temporary receiver.

The receiver is an observation channel. It is never a referee or score source.
Network failures cannot turn a probe into a success or block its ROS callbacks.
"""
from __future__ import annotations

import json
import queue
import threading
import urllib.parse
import urllib.request
from datetime import datetime, timezone


EVENTS = frozenset(("launcher_started", "launcher_exit", "probe_started", "public_graph",
                   "subscription", "sample", "sample_error", "subscription_error",
                   "heartbeat", "probe_finished"))


def _validate(value, depth=0):
    if depth > 12:
        raise ValueError("Diagnostic payload is too deeply nested")
    if isinstance(value, dict):
        for key, child in value.items():
            if not isinstance(key, str) or any(word in key.lower() for word in ("password", "token", "cookie", "secret")):
                raise ValueError("Credentials are forbidden in diagnostic events")
            _validate(child, depth + 1)
    elif isinstance(value, list):
        for child in value:
            _validate(child, depth + 1)


class DiagnosticReporter:
    def __init__(self, url=""):
        self.url = url
        self._closed = False
        self._queue = queue.Queue(maxsize=64)
        self._thread = None
        self.delivered = 0
        self.failed = 0
        if url:
            parsed = urllib.parse.urlsplit(url)
            loopback = parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost", "::1")
            if (not (parsed.scheme == "https" or loopback) or not parsed.hostname
                    or parsed.username or parsed.password or parsed.fragment):
                raise ValueError("Diagnostic endpoint must use HTTPS or loopback HTTP without credentials")
            self._thread = threading.Thread(target=self._send, daemon=True)
            self._thread.start()

    def emit(self, event, data):
        if event not in EVENTS or not isinstance(data, dict):
            raise ValueError("Unknown diagnostic event or invalid data")
        _validate(data)
        payload = json.dumps({"event": event, "timestamp": datetime.now(timezone.utc).isoformat(),
                              "data": data}, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(payload) > 65536:
            raise ValueError("Diagnostic event exceeds 64 KB")
        if not self.url or self._closed:
            return False
        try:
            self._queue.put_nowait(payload)
            return True
        except queue.Full:
            self.failed += 1
            return False

    def _send(self):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        while True:
            payload = self._queue.get()
            try:
                if payload is None:
                    return
                request = urllib.request.Request(self.url, data=payload, method="POST",
                           headers={"Content-Type": "application/json", "User-Agent": "inspection-readonly-probe/1"})
                try:
                    with opener.open(request, timeout=1.5) as response:
                        if response.status != 202:
                            raise ValueError("Receiver did not accept diagnostic event")
                    self.delivered += 1
                except Exception:
                    self.failed += 1
            finally:
                self._queue.task_done()

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._thread:
            try:
                self._queue.put_nowait(None)
            except queue.Full:
                return
            self._thread.join(timeout=3.0)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
