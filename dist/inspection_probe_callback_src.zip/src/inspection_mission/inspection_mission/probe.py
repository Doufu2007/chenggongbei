"""Read-only ROS graph and public sensor/interface probe.

This diagnostic never publishes actuator commands and never reads referee-private
answers. Discovered ROS type names are used directly instead of a profile.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time
from collections.abc import Mapping


PUBLIC_EXACT_TOPICS = (
    "/cmd_vel", "/uav/cmd_vel", "/odom", "/uav/odom",
    "/referee/current_target", "/referee/ground_tasks",
    "/referee/recognition_status", "/referee/events_public",
)
PUBLIC_SENSOR_TYPES = {
    "sensor_msgs/msg/Image", "sensor_msgs/msg/CompressedImage",
    "sensor_msgs/msg/CameraInfo", "sensor_msgs/msg/LaserScan",
    "sensor_msgs/msg/PointCloud2",
}
CONTROL_TOPICS = {"/cmd_vel", "/uav/cmd_vel"}


def select_public_topics(topics):
    """Filter (name, type) pairs before creating any subscriptions."""
    result = []
    for name, ros_type in topics:
        if name.startswith(("/gazebo/", "/ground_truth/", "/truth/", "/private/")):
            continue
        if name.startswith("/referee/") and name not in PUBLIC_EXACT_TOPICS:
            continue
        if (name in PUBLIC_EXACT_TOPICS or name in ("/tf", "/tf_static")
                or ros_type in PUBLIC_SENSOR_TYPES):
            result.append((name, ros_type))
    return sorted(set(result))


def summarize_payload(payload, max_items=8, depth=0):
    """Preserve real field names while bounding arrays and binary sensor data."""
    if depth >= 8:
        return "<depth limit>"
    if isinstance(payload, Mapping):
        return {str(k): summarize_payload(v, max_items, depth + 1)
                for k, v in list(payload.items())[:64]}
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return {"byte_length": len(payload)}
    if isinstance(payload, (list, tuple)) or hasattr(payload, "tolist"):
        values = payload[:max_items].tolist() if hasattr(payload, "tolist") else payload
        return [summarize_payload(v, max_items, depth + 1) for v in values[:max_items]]
    if isinstance(payload, float) and not math.isfinite(payload):
        return str(payload)
    if isinstance(payload, str):
        return payload[:4096]
    if payload is None or isinstance(payload, (bool, int, float)):
        return payload
    return str(payload)[:512]


def create_probe_node(duration_s=30.0, reporter=None):
    """Construct a diagnostic node after importing the installed ROS runtime."""
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from rosidl_runtime_py.convert import message_to_ordereddict
    from rosidl_runtime_py.utilities import get_message

    class InterfaceProbe(Node):
        def __init__(self):
            super().__init__("inspection_interface_probe")
            self.started = time.monotonic()
            self.duration_s = duration_s
            self.finished = False
            self.subscriptions_by_topic = {}
            self.samples = {}
            self.observed_graph = None
            self.create_timer(1.0, self.inspect_graph)
            self.create_timer(5.0, self.heartbeat)
            self.emit("probe_started", {"read_only": True, "duration_s": duration_s})
            self.inspect_graph()

        def emit(self, event, value):
            self.get_logger().info("INTERFACE_PROBE " + json.dumps(
                {"event": event, **value}, ensure_ascii=False, allow_nan=False,
                separators=(",", ":")))
            if reporter is not None:
                reporter.emit(event, value)

        def inspect_graph(self):
            if time.monotonic() - self.started >= self.duration_s:
                self.finished = True
                return
            pairs = [(name, ros_type) for name, types in self.get_topic_names_and_types()
                     for ros_type in types]
            public = select_public_topics(pairs)
            if public != self.observed_graph:
                self.observed_graph = public
                self.emit("public_graph", {"topics": [
                    {"name": name, "type": ros_type,
                     "publishers": self.count_publishers(name),
                     "subscribers": self.count_subscribers(name)}
                    for name, ros_type in public]})
            for name, ros_type in public:
                if name in self.subscriptions_by_topic or name in CONTROL_TOPICS:
                    continue
                try:
                    cls = get_message(ros_type)
                    infos = self.get_publishers_info_by_topic(name)
                    qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT,
                                     durability=DurabilityPolicy.VOLATILE)
                    if infos and all(i.qos_profile.durability == DurabilityPolicy.TRANSIENT_LOCAL for i in infos):
                        qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
                    self.emit("subscription", {"topic": name, "type": ros_type,
                        "fields": cls.get_fields_and_field_types(),
                        "publishers": [{"node": i.node_namespace + "/" + i.node_name,
                            "reliability": str(i.qos_profile.reliability),
                            "durability": str(i.qos_profile.durability)} for i in infos]})
                    self.subscriptions_by_topic[name] = self.create_subscription(
                        cls, name, lambda msg, name=name: self.receive(name, msg), qos)
                except Exception as exc:
                    self.emit("subscription_error", {"topic": name, "error": str(exc)})

        def receive(self, name, msg):
            self.samples[name] = self.samples.get(name, 0) + 1
            if self.samples[name] > 2:
                return
            try:
                self.emit("sample", {"topic": name, "sample_index": self.samples[name],
                                    "message": summarize_payload(message_to_ordereddict(msg))})
            except Exception as exc:
                self.emit("sample_error", {"topic": name, "error": str(exc)})

        def heartbeat(self):
            self.emit("heartbeat", {"elapsed_s": round(time.monotonic() - self.started, 2),
                                    "sample_counts": self.samples})

    return InterfaceProbe()


def main(args=None):
    import rclpy
    from .telemetry import DiagnosticReporter
    parser = argparse.ArgumentParser(description="Read-only public ROS interface diagnostic")
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--report-url", default=os.environ.get("INSPECTION_DIAGNOSTIC_URL", ""))
    parsed, ros_args = parser.parse_known_args(args)
    if not math.isfinite(parsed.duration) or not 1 <= parsed.duration <= 180:
        parser.error("duration must lie in [1,180] seconds")
    rclpy.init(args=ros_args)
    node = None
    reporter = DiagnosticReporter(parsed.report_url)
    try:
        node = create_probe_node(parsed.duration, reporter=reporter)
        while rclpy.ok() and not node.finished:
            rclpy.spin_once(node, timeout_sec=0.5)
        node.emit("probe_finished", {"read_only": True, "sample_counts": node.samples})
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        reporter.close()


if __name__ == "__main__":
    main()
