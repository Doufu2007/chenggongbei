"""Pre-launch validation. No ROS imports and no actuator side effects."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import yaml

from .mission_node import load_configuration


def validate_configuration(config_path: Path | str, *, default_config_dir: Path | str | None = None) -> dict:
    path = Path(config_path).resolve()
    config_root = Path(default_config_dir).resolve() if default_config_dir is not None else path.parent
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("ROS parameter file must be a mapping")
    params = data.get("inspection_mission", {}).get("ros__parameters", {})
    vision = data.get("inspection_vision", {}).get("ros__parameters", {})
    def resolve(name, default):
        raw = params.get(name)
        if not raw:
            return config_root / default
        value = Path(raw)
        if not value.is_absolute():
            raise ValueError(f"{name} must be absolute when configured")
        return value
    overrides = {key: value for key, value in params.items() if key in (
        "pose_timeout_s", "detection_timeout_s", "recognition_stable_s", "illumination_s",
        "phase_timeout_s", "no_progress_timeout_s", "obstacle_timeout_s", "require_ground_order",
    )}
    plan, profile, controller = load_configuration(resolve("plan_path", "mission_plan.json"),
        resolve("interface_profile_path", "interface_profile.json"), overrides)
    settings = controller.settings
    for source in ("ground", "uav"):
        topic = vision.get(source + "_image_topic", "")
        if not isinstance(topic, str) or not topic.startswith("/"):
            raise ValueError(f"missing verified {source} camera topic")
        scan = profile["channels"][source + "_scan"]
        if not scan.get("frame_id") or not isinstance(scan.get("yaw_offset_rad"), (float, int)):
            raise ValueError(f"missing verified {source} scan frame/extrinsics")
    if vision["ground_image_topic"] == vision["uav_image_topic"]:
        raise ValueError("ground/uav camera topics must be distinct")
    if params.get("use_sim_time") is not True or vision.get("use_sim_time") is not True:
        raise ValueError("both nodes must use the simulation clock")
    if params.get("detection_topic", "/inspection/detections") != vision.get("detection_topic", "/inspection/detections"):
        raise ValueError("vision and controller detection topics must match")
    references = json.loads(vision.get("template_paths_json", "{}"))
    if not isinstance(references, dict):
        raise ValueError("template_paths_json must be an object")
    if references:
        from .vision_core import TemplateMatcher
        paths = {}
        for key, value in references.items():
            if not isinstance(value, str) or not Path(value).is_absolute():
                raise ValueError("reference image paths must be absolute in the runtime container")
            paths[key] = value
        TemplateMatcher(paths)
    sizes = json.loads(vision.get("target_sizes_json", "{}"))
    if not isinstance(sizes, dict):
        raise ValueError("target_sizes_json must be an object")
    for size in sizes.values():
        if not isinstance(size, list) or len(size) != 2 or any(isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v) or v <= 0 for v in size):
            raise ValueError("physical target sizes must be positive finite [width,height]")
    return {"plan": plan, "profile": profile, "settings": settings, "vision": vision}


def main(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--default-config-dir", help="installed package share/config root for blank plan/profile paths")
    opts = parser.parse_args(args)
    try:
        validate_configuration(opts.config, default_config_dir=opts.default_config_dir)
    except (ValueError, TypeError, KeyError, OSError) as exc:
        print(f"BLOCKED: {exc}")
        return 2
    print("Configuration complete; platform execution still requires actual ROS interfaces.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
