"""Pure, conservative scan and image geometry; no ROS or simulator dependencies."""

from __future__ import annotations

import math

import cv2
import numpy as np


def scan_path_clear(ranges, *, angle_min: float, angle_increment: float,
                    world_direction: float, robot_yaw: float, stop_distance: float,
                    sector_half_angle: float = 0.26, range_min: float = 0.0,
                    range_max: float = math.inf, scan_yaw_offset: float = 0.0,
                    min_valid_fraction: float = 0.7, min_valid_beams: int = 3,
                    corridor_radius: float = 0.15) -> bool:
    """Check a sector around world travel direction in the actual scan frame.

    Angles are radians; ``scan_yaw_offset`` is the measured scan-to-base yaw.
    Missing/FOV-limited/invalid observations fail closed. Positive infinity is a
    clear ray only when a finite declared maximum range covers stop_distance.
    This is a local collision guard, not global navigation or a 3D free-space map.
    """
    try:
        scan = np.asarray(ranges, dtype=float).reshape(-1)
        metadata = [angle_min, angle_increment, world_direction, robot_yaw,
                    stop_distance, sector_half_angle, range_min, scan_yaw_offset, min_valid_fraction, corridor_radius]
        if (not scan.size or not np.isfinite(metadata).all() or angle_increment == 0
                or stop_distance <= 0 or corridor_radius <= 0 or not 0 < sector_half_angle < math.pi
                or range_min < 0 or range_min >= stop_distance or range_max <= range_min or math.isnan(range_max)
                or not 0 < min_valid_fraction <= 1 or min_valid_beams < 1):
            return False
        direction = world_direction - robot_yaw - scan_yaw_offset
        angles = angle_min + np.arange(scan.size) * angle_increment
        relative = np.arctan2(np.sin(angles - direction), np.cos(angles - direction))
        # A narrow forward cone misses close obstacles near the robot's side.
        # Check the full observed swept footprint before evaluating clear rays.
        valid_all = np.isfinite(scan) & (scan >= range_min) & (scan > 0) & (scan <= range_max)
        forward = np.zeros_like(scan)
        lateral = np.zeros_like(scan)
        forward[valid_all] = scan[valid_all] * np.cos(relative[valid_all])
        lateral[valid_all] = scan[valid_all] * np.sin(relative[valid_all])
        if np.any(valid_all & (forward >= 0) & (forward <= stop_distance) & (np.abs(lateral) <= corridor_radius)):
            return False
        selected = np.abs(relative) <= sector_half_angle + 1e-9
        rays = scan[selected]
        offsets = relative[selected]
        step = abs(angle_increment)
        expected = max(min_valid_beams, int(math.floor(2 * sector_half_angle / step)))
        if (rays.size < expected or rays.size < min_valid_beams
                or offsets.min() > -sector_half_angle + step
                or offsets.max() < sector_half_angle - step):
            return False
        finite_valid = np.isfinite(rays) & (rays >= range_min) & (rays > 0) & (rays <= range_max)
        if np.any(finite_valid & (rays <= stop_distance)):
            return False
        no_return = np.isposinf(rays) & math.isfinite(range_max) & (range_max > stop_distance)
        valid = finite_valid | no_return
        return bool(valid.sum() >= min_valid_beams and valid.mean() >= min_valid_fraction)
    except (TypeError, ValueError, OverflowError):
        return False


def aim_centered(center, tolerance_x: float = 0.05, tolerance_y: float = 0.05) -> bool:
    """Whether an observed normalized image point lies in the aim deadband."""
    try:
        point = np.asarray(center, dtype=float)
        if (point.shape != (2,) or not np.isfinite(point).all()
                or (point < 0).any() or (point > 1).any()
                or not math.isfinite(tolerance_x) or not math.isfinite(tolerance_y)
                or tolerance_x < 0 or tolerance_y < 0):
            return False
        return bool(abs(point[0] - 0.5) <= tolerance_x and abs(point[1] - 0.5) <= tolerance_y)
    except (TypeError, ValueError):
        return False


def pointcloud_path_clear(points_xyz, velocity_xyz, *, stop_distance: float,
                          corridor_radius: float, min_valid_points: int = 3) -> bool:
    """Guard a sampled 3D cylinder in one explicitly confirmed local frame.

    Points and velocity must already share that frame. Any point within the
    forward stopping cylinder blocks. At least min_valid_points finite returns
    must sample this direction beyond the stopping distance to return True.
    This checks observed returns only; it does not prove unknown space is free.
    LaserScan cannot substitute for this 3D check during ascent/descent.
    """
    try:
        points = np.asarray(points_xyz, dtype=float)
        velocity = np.asarray(velocity_xyz, dtype=float)
        if (points.ndim != 2 or points.shape[1] != 3 or velocity.shape != (3,)
                or not np.isfinite(velocity).all() or np.linalg.norm(velocity) < 1e-9
                or not math.isfinite(stop_distance) or stop_distance <= 0
                or not math.isfinite(corridor_radius) or corridor_radius <= 0
                or min_valid_points < 1):
            return False
        points = points[np.isfinite(points).all(axis=1)]
        if len(points) < min_valid_points:
            return False
        direction = velocity / np.linalg.norm(velocity)
        forward = points @ direction
        radial = np.linalg.norm(points - forward[:, None] * direction, axis=1)
        in_corridor = (forward >= 0) & (radial <= corridor_radius)
        if np.any(in_corridor & (forward <= stop_distance)):
            return False
        return bool(np.count_nonzero(in_corridor & (forward > stop_distance)) >= min_valid_points)
    except (TypeError, ValueError, OverflowError):
        return False


def camera_target_position(corners_px, camera_matrix, distortion=None, *, target_size_m,
                           max_reprojection_error_px: float = 3.0) -> tuple[float, float, float] | None:
    """Solve a known rectangle's center in optical-camera metres (x right,y down,z forward).

    Corners must correspond to reference top-left, top-right, bottom-right,
    bottom-left. A real CameraInfo calibration and user-supplied physical width
    and height are required. This never invents size or an extrinsic transform.
    """
    try:
        size = np.asarray(target_size_m, dtype=np.float64)
        corners = np.asarray(corners_px, dtype=np.float64)
        camera = np.asarray(camera_matrix, dtype=np.float64).reshape(3, 3)
        if (size.shape != (2,) or not np.isfinite(size).all() or (size <= 0).any()
                or corners.shape != (4, 2) or not np.isfinite(corners).all()
                or not np.isfinite(camera).all() or camera[0, 0] <= 0 or camera[1, 1] <= 0
                or abs(camera[2, 2] - 1) > 1e-6
                or not cv2.isContourConvex(corners.astype(np.float32))
                or abs(cv2.contourArea(corners.astype(np.float32))) < 4
                or not math.isfinite(max_reprojection_error_px) or max_reprojection_error_px <= 0):
            return None
        distortion = np.asarray(distortion if distortion is not None else np.zeros(5), dtype=np.float64)
        if not np.isfinite(distortion).all():
            return None
        width, height = size
        model = np.float64([[-width / 2, -height / 2, 0], [width / 2, -height / 2, 0],
                            [width / 2, height / 2, 0], [-width / 2, height / 2, 0]])
        success, rotation, translation = cv2.solvePnP(model, corners, camera, distortion,
                                                     flags=cv2.SOLVEPNP_ITERATIVE)
        if not success or not np.isfinite(translation).all() or translation[2, 0] <= 0:
            return None
        projected, _ = cv2.projectPoints(model, rotation, translation, camera, distortion)
        error = np.linalg.norm(projected.reshape(4, 2) - corners, axis=1).max()
        if not np.isfinite(error) or error > max_reprojection_error_px:
            return None
        return tuple(float(value) for value in translation.ravel())
    except (TypeError, ValueError, cv2.error):
        return None
