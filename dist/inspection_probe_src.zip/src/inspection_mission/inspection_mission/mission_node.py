"""ROS adapter; interfaces are validated before actuator publishers exist.

ROS imports stay in create_node(), allowing real configuration validation on
non-ROS hosts. No platform interface, map or recognition answer is guessed.
"""
from __future__ import annotations

import json
import math
from dataclasses import replace
from pathlib import Path

from .mission import MissionController
from .protocol import build_payload, planar_velocity, validate_profile
from .runtime import RuntimeInputs, flight_motion_intent, number


def _json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate configuration key: {key}")
        result[key] = value
    return result


def validate_outbound_fields(profile):
    """Validate templates against fields supplied by that channel at runtime."""
    recognition = {"event_id": "validation:0", "id": "validation:0", "point_id": "measured-point", "target_id": "validation",
                   "source": "ground", "stamp": 0.0, "state": "VALIDATION", "pose": [0.0]*4}
    samples = {"recognition": recognition, "light": {"enabled": False, "stamp": 0.0, "state": "STOP"}}
    if profile["flight_mode"] == "trigger":
        if profile.get("trigger_abort_stops_motion") is not True or "flight_abort" not in profile["channels"]:
            raise ValueError("trigger flight requires a confirmed emergency abort contract")
        flight_motion_intent((0, 0, 0, 0), "TAKEOFF", profile)
        for key in ("takeoff", "land", "flight_abort"):
            samples[key] = {"enabled": True, "stamp": 0.0, "state": "VALIDATION"}
    result = {}
    for key, sample in samples.items():
        fields = profile["channels"][key].get("fields")
        if not isinstance(fields, dict):
            raise ValueError(f"missing confirmed message template: {key}")
        result[key] = build_payload(fields, sample)
    return result


def resolve_runtime_path(value, default):
    if not value:
        return Path(default)
    path = Path(value)
    if not path.is_absolute():
        raise ValueError("explicit plan/profile paths must be absolute")
    return path


def load_configuration(plan_path, interface_profile_path, settings=None):
    """Load strict JSON and validate critical settings without importing ROS."""
    def load(path):
        def nonfinite(value):
            raise ValueError(f"nonfinite JSON value: {value}")
        payload = json.loads(Path(path).read_text(encoding="utf-8"),
                             object_pairs_hook=_json_object, parse_constant=nonfinite)
        if not isinstance(payload, dict):
            raise ValueError("configuration root must be an object")
        return payload

    profile = validate_profile(load(interface_profile_path))
    validate_outbound_fields(profile)
    plan = load(plan_path)
    supplied = plan.get("settings", {})
    if not isinstance(supplied, dict):
        raise ValueError("mission settings must be an object")
    controller = MissionController(plan, {**supplied, **(settings or {})})
    RuntimeInputs(profile, {point["id"] for point in plan["ground_points"]},
                  sensor_timeout_s=controller.settings["pose_timeout_s"],
                  detection_timeout_s=controller.settings["detection_timeout_s"])
    return plan, profile, controller


def create_node():
    """Construct the node with actual ROS2 Humble dependencies."""
    from ament_index_python.packages import get_package_share_directory
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
    from rosidl_runtime_py.utilities import get_message
    from rosidl_runtime_py.convert import message_to_ordereddict
    from rosidl_runtime_py.set_message import set_message_fields
    from std_msgs.msg import String

    class InspectionMissionNode(Node):
        def __init__(self):
            super().__init__("inspection_mission")
            config_dir = Path(get_package_share_directory("inspection_mission")) / "config"
            for key, default in {
                "plan_path": str(config_dir / "mission_plan.json"),
                "interface_profile_path": str(config_dir / "interface_profile.json"),
                "detection_topic": "/inspection/detections",
                "mission_status_topic": "/inspection/mission_status",
                "control_rate_hz": 20.0,
            }.items():
                self.declare_parameter(key, default)
            controller_defaults = {
                "phase_timeout_s": 90.0, "pose_timeout_s": 0.5, "detection_timeout_s": 0.35,
                "recognition_stable_s": 0.5, "illumination_s": 2.0, "no_progress_timeout_s": 8.0,
                "obstacle_timeout_s": 4.0, "require_ground_order": True,
            }
            for key, default in controller_defaults.items():
                self.declare_parameter(key, default)
            self.declare_parameter("scan_timeout_s", 0.5)
            parameter = lambda key: self.get_parameter(key).value
            plan, self.profile, self.controller = load_configuration(
                resolve_runtime_path(parameter("plan_path"), config_dir / "mission_plan.json"),
                resolve_runtime_path(parameter("interface_profile_path"), config_dir / "interface_profile.json"),
                settings={key: parameter(key) for key in controller_defaults})
            rate = number(parameter("control_rate_hz"), "control_rate_hz")
            if not 1 <= rate <= 100:
                raise ValueError("control_rate_hz must lie in [1,100]")
            self.channels = self.profile["channels"]
            self.inputs = RuntimeInputs(self.profile, {p["id"] for p in plan["ground_points"]},
                                        sensor_timeout_s=self.controller.settings["pose_timeout_s"],
                                        detection_timeout_s=self.controller.settings["detection_timeout_s"],
                                        scan_timeout_s=parameter("scan_timeout_s"))
            self.runtime_fault = ""
            self._blocked_since = None
            self._flight_sent = set()
            self._flight_cancelled = False
            self._logged_errors = {}
            self._pubs, self._subs = {}, []
            self._types = {key: get_message(spec["type"]) for key, spec in self.channels.items()}
            outbound = ["ground_cmd", "uav_cmd", "recognition", "light"]
            if self.profile["flight_mode"] == "trigger":
                outbound += ["takeoff", "land", "flight_abort"]
            # Validate type and field bindings before creating actuator publishers.
            for key, fields in validate_outbound_fields(self.profile).items():
                set_message_fields(self._types[key](), fields)
            for key in outbound:
                self._pubs[key] = self.create_publisher(self._types[key], self.channels[key]["topic"],
                                                       self._qos(self.channels[key]))
            self._status = self.create_publisher(String, str(parameter("mission_status_topic")), 10)
            for source in ("ground", "uav"):
                for kind in ("odom", "scan"):
                    self._subscribe(source + "_" + kind,
                                    lambda msg, source=source, kind=kind: self._sensor_callback(source, kind, msg),
                                    sensor=True)
            self._subscribe("ground_tasks", lambda msg: self._receive("ground_tasks", self.inputs.update_order, msg))
            self._subscribe("recognition_ack", lambda msg: self._receive("recognition_ack", self.inputs.update_ack, msg))
            self._subscribe("light_feedback", lambda msg: self._receive(
                "light_feedback", lambda value: self.inputs.update_light(value, now=self._now()), msg))
            if "uav_cloud" in self.channels:
                self._subscribe("uav_cloud", self._cloud_callback, sensor=True)
            self._subs.append(self.create_subscription(String, str(parameter("detection_topic")), self._detections_callback, 10))
            self.create_timer(1.0 / rate, self._tick)
            self.create_timer(1.0, self._heartbeat)
            self.get_logger().info("Complete inspection controller ready; waiting for confirmed interfaces and observations")
            if "uav_cloud" not in self.channels:
                self.get_logger().warning("UAV scan guard is planar; vertical clearance relies on the measured mission plan")

        def _now(self):
            return self.get_clock().now().nanoseconds / 1e9

        def _qos(self, spec, sensor=False):
            config = spec.get("qos", {})
            reliability = config.get("reliability", "best_effort" if sensor else "reliable")
            durability = config.get("durability", "volatile")
            if reliability not in ("best_effort", "reliable") or durability not in ("volatile", "transient_local"):
                raise ValueError("unsupported QoS reliability/durability")
            return QoSProfile(depth=10,
                              reliability=ReliabilityPolicy.BEST_EFFORT if reliability == "best_effort" else ReliabilityPolicy.RELIABLE,
                              durability=DurabilityPolicy.TRANSIENT_LOCAL if durability == "transient_local" else DurabilityPolicy.VOLATILE)

        def _subscribe(self, key, callback, sensor=False):
            self._subs.append(self.create_subscription(self._types[key], self.channels[key]["topic"], callback,
                                                       self._qos(self.channels[key], sensor)))

        def _error(self, key, exc):
            detail = f"{key}:{type(exc).__name__}:{exc}"
            self.inputs.errors[key] = detail
            if self._logged_errors.get(key) != detail:
                self.get_logger().error(detail)
                self._logged_errors[key] = detail
            self._stop()

        def _receive(self, key, parser, msg):
            try:
                parser(message_to_ordereddict(msg))
                self.inputs.errors.pop(key, None)
            except Exception as exc:
                self._error(key, exc)

        def _sensor_callback(self, source, kind, msg):
            key = source + "_" + kind
            try:
                function = self.inputs.update_pose if kind == "odom" else self.inputs.update_scan
                function(source, message_to_ordereddict(msg), now=self._now())
            except Exception as exc:
                if kind == "odom":
                    self.inputs.poses[source] = None
                else:
                    self.inputs.scans[source] = None
                self._error(key, exc)

        def _cloud_callback(self, msg):
            try:
                from sensor_msgs_py import point_cloud2
                points = point_cloud2.read_points_numpy(msg, field_names=("x", "y", "z"), skip_nans=False)
                self.inputs.update_cloud(message_to_ordereddict(msg.header), points, now=self._now())
            except Exception as exc:
                self.inputs.cloud = None
                self._error("uav_cloud", exc)

        def _detections_callback(self, msg):
            try:
                self.inputs.update_detections(json.loads(msg.data), now=self._now())
                self.inputs.errors.pop("detections", None)
            except Exception as exc:
                self.inputs.frames = {"ground": None, "uav": None}
                self._error("detections", exc)

        def _connected(self):
            if any(pub.get_subscription_count() == 0 for pub in self._pubs.values()):
                return False
            required = ["ground_odom", "uav_odom", "ground_scan", "uav_scan", "recognition_ack", "light_feedback"]
            if self.controller.settings["require_ground_order"]:
                required.append("ground_tasks")
            if "uav_cloud" in self.channels:
                required.append("uav_cloud")
            return all(self.count_publishers(self.channels[key]["topic"]) > 0 for key in required)

        def _message(self, key, values):
            msg = self._types[key]()
            set_message_fields(msg, build_payload(self.channels[key]["fields"], values))
            return msg

        def _stop(self):
            errors = []
            for key in ("ground_cmd", "uav_cmd"):
                try:
                    self._pubs[key].publish(self._types[key]())
                except Exception as exc:
                    errors.append(key + ":" + str(exc))
            try:
                self._pubs["light"].publish(self._message("light", {"enabled": False, "stamp": self._now(), "state": "STOP"}))
            except Exception as exc:
                errors.append("light_off:" + str(exc))
            if (self.profile["flight_mode"] == "trigger" and self._flight_sent
                    and not self._flight_cancelled and not self.controller.completed):
                try:
                    self._pubs["flight_abort"].publish(self._message(
                        "flight_abort", {"enabled": True, "stamp": self._now(), "state": "ABORT"}))
                    self._flight_cancelled = True
                    self.runtime_fault = self.runtime_fault or "trigger_flight_aborted"
                except Exception as exc:
                    errors.append("flight_abort:" + str(exc))
            if errors:
                detail = "stop_delivery_failed:" + ";".join(errors)
                self.runtime_fault = self.runtime_fault or detail
                self.inputs.errors["stop"] = detail
                self.get_logger().error(detail)

        def _publish(self, command):
            ground = self._types["ground_cmd"]()
            ground.linear.x, ground.angular.z = command.ground
            aerial = self._types["uav_cmd"]()
            vx, vy, vz, yaw_rate = command.uav
            pose = self.inputs.poses["uav"]
            if any(abs(value) > 1e-12 for value in (vx, vy, vz, yaw_rate)) and pose is None:
                raise ValueError("cannot transform UAV command without pose")
            bx, by = planar_velocity(vx, vy, pose.yaw if pose else 0.0, self.profile["uav_velocity_frame"])
            aerial.linear.x, aerial.linear.y, aerial.linear.z, aerial.angular.z = bx, by, vz, yaw_rate
            if self.profile["flight_mode"] == "trigger" and command.state in ("TAKEOFF", "LAND"):
                aerial = self._types["uav_cmd"]()
                if (command.state not in self._flight_sent and not command.fault
                        and self._blocked_since is None and not self.runtime_fault):
                    key = command.state.lower()
                    self._pubs[key].publish(self._message(key, {"enabled": True, "stamp": self._now(), "state": command.state}))
                    self._flight_sent.add(command.state)
            self._pubs["ground_cmd"].publish(ground)
            self._pubs["uav_cmd"].publish(aerial)
            self._pubs["light"].publish(self._message("light", {"enabled": command.light, "stamp": self._now(), "state": command.state}))
            if command.recognition is not None:
                self._pubs["recognition"].publish(self._message("recognition", command.recognition))

        def _tick(self):
            try:
                now = self._now()
                if self.runtime_fault or self.inputs.fault:
                    self._stop()
                    return
                command = self.controller.step(
                    now, self.inputs.poses["ground"], self.inputs.poses["uav"], self.inputs.fresh_detections(now),
                    ground_clear=self.inputs.scan_fresh("ground", now), uav_clear=self.inputs.scan_fresh("uav", now),
                    light_ready=self.inputs.light_ready(now), controls_ready=self._connected(),
                    recognition_ack=self.inputs.acknowledgements, ground_order=self.inputs.order)
                vehicle = self.controller.active_vehicle
                if vehicle != "none":
                    velocity = (command.ground if vehicle == "ground" else
                                flight_motion_intent(command.uav, command.state, self.profile))
                    radius, clearance = self.controller.plan["robot_radius_m"], self.controller.plan["clearance_m"]
                    speed = abs(velocity[0]) if vehicle == "ground" else math.sqrt(sum(v*v for v in velocity[:3]))
                    distance = radius + clearance + speed * max(self.inputs.sensor_timeout_s, self.inputs.scan_timeout_s)
                    clear = self.inputs.motion_clear(vehicle, velocity, now, stop_distance=distance, corridor_radius=radius+clearance)
                    if not clear:
                        if self._blocked_since is None:
                            self._blocked_since = now
                        if now - self._blocked_since >= self.controller.settings["obstacle_timeout_s"]:
                            self.runtime_fault = "motion_path_blocked_or_unobserved:" + vehicle
                        if self.profile["flight_mode"] == "trigger" and self._flight_sent:
                            self.runtime_fault = "trigger_flight_path_blocked"
                        command = replace(command, ground=(0.0, 0.0), uav=(0.0, 0.0, 0.0, 0.0), light=False, recognition=None)
                    else:
                        self._blocked_since = None
                self._publish(command)
                if command.fault or command.done or self.runtime_fault:
                    self._stop()
            except Exception as exc:
                self.runtime_fault = f"runtime_exception:{type(exc).__name__}:{exc}"
                self.get_logger().error(self.runtime_fault)
                self._stop()

        def _heartbeat(self):
            try:
                now = self._now()
                message = String()
                message.data = json.dumps({"stamp": now, "session_id": self.controller.session_id,
                                           "state": "FAILSAFE" if self.runtime_fault or self.inputs.fault else self.controller.state,
                                           "done": self.controller.completed and not (self.runtime_fault or self.inputs.fault),
                                           "fault": self.runtime_fault or self.inputs.fault or self.controller.fault_reason,
                                           "errors": self.inputs.errors,
                                           "pose_fresh": {s: self.inputs.pose_fresh(s, now) for s in ("ground", "uav")},
                                           "scan_fresh": {s: self.inputs.scan_fresh(s, now) for s in ("ground", "uav")}},
                                          ensure_ascii=False, allow_nan=False)
                self._status.publish(message)
            except Exception as exc:
                self.runtime_fault = "status_exception:" + str(exc)
                self._stop()

    return InspectionMissionNode()


def main(args=None):
    import rclpy
    rclpy.init(args=args)
    node = None
    try:
        node = create_node()
        rclpy.spin(node)
    finally:
        if node is not None:
            node._stop()
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
